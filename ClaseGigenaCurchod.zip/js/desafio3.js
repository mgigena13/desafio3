let tabla = Number(prompt("Que tabla queres saber???"));

for (let i = 1; i<=10; i++){
    let resultado = tabla * i;
    alert (tabla + " X " + i + " = " + resultado);
    console.log(tabla + " X " + i + " = " + resultado);
}
